<?php

namespace App\Http\Controllers;

use App\Models\Aircraft;
use App\Models\EsdItem;
use App\Models\Supplier;
use App\Models\ShelfLocation;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class EsdItemController extends Controller
{
    public function index()
    {
        return view('esd-items.index');
    }

    public function create()
    {
        $suppliers = Supplier::all();
        $locations = ShelfLocation::all();
        $aircrafts = Aircraft::all();
        return view('esd-items.create', compact('suppliers', 'locations', 'aircrafts'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'part_number' => 'required|string',
            'description' => 'nullable|string',
            'serial_number' => 'required|string',
            'quantity' => 'required|integer',
            'aircraft_registration' => 'required|string',
            'remark' => 'nullable|string',
            'status' => 'required|string',
            'airway_bill' => 'nullable|string',
            'supplier_id' => 'required|exists:suppliers,id',
            'location_id' => 'required|exists:shelf_locations,id',
            'received_date' => 'required|date',
        ]);

        DB::transaction(function () use ($request) {
            EsdItem::create($request->merge(['received_by_id' => Auth::id()])->all());
        });

        return redirect()->route('esd-items.index')->with('success', 'ESD Item created successfully.');
    }

    public function edit(EsdItem $esdItem)
    {
        $suppliers = Supplier::all();
        $locations = ShelfLocation::all();
        $aircrafts = Aircraft::all();
        return view('esd-items.edit', compact('esdItem', 'suppliers', 'locations', 'aircrafts'));
    }

    public function update(Request $request, EsdItem $esdItem)
    {
        $request->validate([
            'part_number' => 'required|string',
            'description' => 'nullable|string',
            'serial_number' => 'required|string',
            'quantity' => 'required|integer',
            'aircraft_registration' => 'required|string',
            'remark' => 'nullable|string',
            'status' => 'required|string',
            'airway_bill' => 'nullable|string',
            'supplier_id' => 'required|exists:suppliers,id',
            'location_id' => 'required|exists:shelf_locations,id',
            'received_date' => 'required|date',
        ]);

        DB::transaction(function () use ($request, $esdItem) {
            $esdItem->update($request->merge(['received_by_id' => Auth::id()])->all());
        });

        return redirect()->route('esd-items.index')->with('success', 'ESD Item updated successfully.');
    }

    public function destroy(EsdItem $esdItem)
    {
        $esdItem->delete();
        return redirect()->route('esd-items.index')->with('success', 'ESD Item deleted successfully.');
    }
}
